export function CardPage({ eyebrow, title, description, children }) {
  return (
    <section className='simple-box simple-box--page'>
      <div className='box-intro'>
        {eyebrow && <span>{eyebrow}</span>}
        <h1>{title}</h1>
        {description && <p>{description}</p>}
      </div>
      {children}
    </section>
  )
}
