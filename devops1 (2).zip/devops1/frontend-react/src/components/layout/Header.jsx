import { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'

export function Header({ token, cartCount, onLogout }) {
  const [showNav, setShowNav] = useState(false)

  return (
    <header className='simple-header'>
      <div className='simple-header__top'>
        <Link className='simple-logo' to='/'>
          Линия одежды
        </Link>

        <button
          type='button'
          className='menu-button'
          onClick={() => setShowNav(!showNav)}
          aria-label='Открыть меню'
        >
          Меню
        </button>
      </div>

      <div className={`simple-header__nav ${showNav ? 'simple-header__nav--open' : ''}`}>
        <nav className='simple-links'>
          <NavLink className='simple-link' to='/'>Витрина</NavLink>
          <NavLink className='simple-link' to='/cabinet'>Кабинет</NavLink>
          <NavLink className='simple-link' to='/admin'>Админка</NavLink>
        </nav>

        <div className='simple-actions'>
          <span className='cart-label'>Товаров в корзине: {cartCount}</span>
          {token ? (
            <button type='button' className='simple-button simple-button--light' onClick={onLogout}>
              Выйти
            </button>
          ) : (
            <>
              <Link className='simple-button simple-button--light' to='/login'>Вход</Link>
              <Link className='simple-button' to='/register'>Регистрация</Link>
            </>
          )}
        </div>
      </div>
    </header>
  )
}
