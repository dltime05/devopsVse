import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { CardPage } from '../components/common/CardPage'
import { loginUser, registerUser } from '../services/authService'

export function RegisterPage({ cfg, onAuth }) {
  const [login, setLogin] = useState('')
  const [password, setPassword] = useState('')
  const [message, setMessage] = useState('')
  const navigate = useNavigate()

  async function submit(event) {
    event.preventDefault()
    const registerResponse = await registerUser(cfg.authBaseUrl, login, password)
    if (!registerResponse.ok && registerResponse.status !== 409) {
      setMessage(`Ошибка регистрации: ${await registerResponse.text()}`)
      return
    }

    const { response, body } = await loginUser(cfg.authBaseUrl, login, password)
    if (!response.ok || !body.json?.token) {
      setMessage(`Регистрация выполнена, но вход не выполнен: ${body.text}`)
      return
    }

    onAuth(body.json.token, login)
    navigate('/')
  }

  return (
    <CardPage
      title='Регистрация'
      description='Создайте аккаунт, чтобы сохранять сессию и пользоваться заказами.'
    >
      <form onSubmit={submit} className='form-stack'>
        <label className='field'>
          <span>Логин</span>
          <input value={login} onChange={(e) => setLogin(e.target.value)} required />
        </label>
        <label className='field'>
          <span>Пароль</span>
          <input type='password' value={password} onChange={(e) => setPassword(e.target.value)} required />
        </label>
        <button type='submit' className='simple-button simple-button--full'>Создать аккаунт</button>
        {message && <p className='message-line message-line--error'>{message}</p>}
      </form>
    </CardPage>
  )
}
