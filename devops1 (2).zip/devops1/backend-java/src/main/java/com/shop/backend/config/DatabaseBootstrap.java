package com.shop.backend.config;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class DatabaseBootstrap {
    public DatabaseBootstrap(JdbcTemplate jdbcTemplate) {
        jdbcTemplate.execute("ALTER TABLE products ADD COLUMN IF NOT EXISTS image_url TEXT");
        jdbcTemplate.execute("ALTER TABLE orders ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ");
        jdbcTemplate.execute("UPDATE products SET image_url = '/media/shop-images/products/tshirt.svg' WHERE name = 'Хлопковая футболка' AND (image_url IS NULL OR image_url = '')");
        jdbcTemplate.execute("UPDATE products SET image_url = '/media/shop-images/products/shirt.svg' WHERE name = 'Льняная рубашка' AND (image_url IS NULL OR image_url = '')");
        jdbcTemplate.execute("UPDATE products SET image_url = '/media/shop-images/products/hoodie.svg' WHERE name = 'Светлый худи' AND (image_url IS NULL OR image_url = '')");
    }
}
