CREATE TABLE IF NOT EXISTS products (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL UNIQUE,
  price DOUBLE PRECISION NOT NULL,
  image_url TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS orders (
  id BIGSERIAL PRIMARY KEY,
  user_login VARCHAR(255) NOT NULL,
  product_id BIGINT NOT NULL,
  quantity INTEGER NOT NULL,
  status VARCHAR(32) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE products ADD COLUMN IF NOT EXISTS image_url TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ;
UPDATE products SET image_url = '/media/shop-images/products/tshirt.svg' WHERE name = 'Хлопковая футболка' AND (image_url IS NULL OR image_url = '');
UPDATE products SET image_url = '/media/shop-images/products/shirt.svg' WHERE name = 'Льняная рубашка' AND (image_url IS NULL OR image_url = '');
UPDATE products SET image_url = '/media/shop-images/products/hoodie.svg' WHERE name = 'Светлый худи' AND (image_url IS NULL OR image_url = '');

INSERT INTO products (name, price, image_url) VALUES
('Хлопковая футболка', 19.99, '/media/shop-images/products/tshirt.svg'),
('Льняная рубашка', 34.99, '/media/shop-images/products/shirt.svg'),
('Светлый худи', 44.99, '/media/shop-images/products/hoodie.svg')
ON CONFLICT (name) DO NOTHING;

DELETE FROM products WHERE name = 'Admin Test Product';
DELETE FROM products WHERE name = 'Laptop';
DELETE FROM products WHERE name = 'Headphones';
DELETE FROM products WHERE name = 'Mouse';
DELETE FROM products WHERE name = 'Ceramic Mug';
DELETE FROM products WHERE name = 'Scented Candle';
DELETE FROM products WHERE name = 'Potted Plant';
DELETE FROM products WHERE name = 'Керамическая кружка';
DELETE FROM products WHERE name = 'Ароматическая свеча';
DELETE FROM products WHERE name = 'Комнатное растение';
DELETE FROM products WHERE name = 'Чашка для чая';
DELETE FROM products WHERE name = 'Свеча с лавандой';
DELETE FROM products WHERE name = 'Фикус в горшке';
