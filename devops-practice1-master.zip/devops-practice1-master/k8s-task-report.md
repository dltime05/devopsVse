# Отчет по задаче: развертывание REST-приложения в Kubernetes

## 1. Цель работы

Целью работы было развернуть простое REST-приложение в Kubernetes и проверить его работоспособность. По условию задачи необходимо было:

- развернуть и настроить Kubernetes любым удобным способом;
- подготовить REST-приложение, которое возвращает HTML-страницу;
- сделать так, чтобы приложение принимало параметр из переменной окружения или конфигурационного файла;
- собрать Docker-образ приложения и разместить его в Docker Hub;
- развернуть приложение в Kubernetes с использованием `Deployment`, `ConfigMap`, `Service`, `Ingress`;
- проверить работоспособность приложения.

В рамках выполнения задачи было подготовлено простое приложение на Python с использованием Flask. Приложение обрабатывает HTTP-запрос на корневой маршрут `/` и возвращает HTML-страницу с приветствием. Значение имени берется из переменной окружения `NAME`, которая передается в контейнер через Kubernetes `ConfigMap`.

В качестве Kubernetes-окружения использовался Kubernetes, встроенный в Docker Desktop. Такой вариант подходит для локальной разработки и учебной проверки, потому что позволяет быстро поднять кластер на рабочем компьютере без отдельного сервера.
---

## 2. Используемые инструменты и окружение

Для выполнения работы использовались следующие инструменты:

- операционная система: Windows;
- Docker Desktop;
- Kubernetes в Docker Desktop;
- `kubectl` для управления ресурсами Kubernetes;
- Python;
- Flask;
- Docker Hub для хранения собранного Docker-образа;
- GitHub-репозиторий, в котором выполнялась работа.

Проверка текущего контекста Kubernetes выполнялась командой:

```powershell
kubectl config get-contexts
```

Результат показал, что активным контекстом является `docker-desktop`:

```text
CURRENT   NAME             CLUSTER          AUTHINFO         NAMESPACE
*         docker-desktop   docker-desktop   docker-desktop
```

Также была выполнена проверка доступности Kubernetes-кластера:

```powershell
kubectl cluster-info
```

Пример результата:

```text
Kubernetes control plane is running at https://127.0.0.1:57737
CoreDNS is running at https://127.0.0.1:57737/api/v1/namespaces/kube-system/services/kube-dns:dns/proxy
```

Эти команды подтверждают, что локальный Kubernetes-кластер запущен и `kubectl` может к нему подключаться.

---

## 3. Структура проекта

Работа выполнялась в существующем GitHub-репозитории. Для Kubernetes-задачи была использована директория `k8s-app`, в которой находятся приложение, Dockerfile и Kubernetes-манифесты.

Основные файлы:

```text
k8s-app/
  main.py
  Dockerfile
  configmap.yaml
  deployment-fixed.yaml
```

Назначение файлов:

- `main.py` - исходный код Flask-приложения;
- `Dockerfile` - инструкция для сборки Docker-образа;
- `configmap.yaml` - конфигурация Kubernetes `ConfigMap`;
- `deployment-fixed.yaml` - манифесты `Deployment`, `Service` и `Ingress`.

Также в корне репозитория присутствуют файлы `main.py`, `Dockerfile` и `requirements.txt`, но для развертывания в Kubernetes использовалась директория `k8s-app`.


---

## 4. REST-приложение

Приложение реализовано на Python с использованием микрофреймворка Flask. Оно запускает веб-сервер на порту `8080` и обрабатывает запросы на маршрут `/`.

Код приложения:

```python
from flask import Flask
import os

app = Flask(__name__)

@app.route('/')
def hello():
    name = os.getenv('NAME', 'Guest')
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>K8S Hello App</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                margin: 50px;
                text-align: center;
                background-color: #eef4ff;
            }}
            h1 {{
                color: #2563eb;
            }}
        </style>
    </head>
    <body>
        <h1>Hello, {name}!</h1>
        <p>Переменная окружения NAME = <strong>{name}</strong></p>
        <hr>
        <small>Deployment + ConfigMap + Service + Ingress</small>
    </body>
    </html>
    '''

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
```

Главная особенность приложения состоит в том, что оно получает значение из переменной окружения:

```python
name = os.getenv('NAME', 'Guest')
```

Если переменная `NAME` задана, ее значение отображается на HTML-странице. Если переменная не задана, используется значение по умолчанию `Guest`.

В рамках развертывания в Kubernetes переменная окружения `NAME` получает значение из `ConfigMap`. В данном проекте задано значение:

```text
DevOps
```

Поэтому при открытии страницы пользователь видит:

```html
<h1>Hello, DevOps!</h1>
```
---

## 5. Сборка Docker-образа и публикация в Docker Hub

Для запуска приложения в Kubernetes был подготовлен Docker-образ. В директории `k8s-app` находится файл `Dockerfile`.

Содержимое Dockerfile:

```dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY main.py .

RUN pip install "flask>=3.1,<4"

EXPOSE 8080

CMD ["python", "main.py"]
```

Описание шагов Dockerfile:

- `FROM python:3.9-slim` - используется базовый образ Python;
- `WORKDIR /app` - задается рабочая директория внутри контейнера;
- `COPY main.py .` - в контейнер копируется исходный файл приложения;
- `RUN pip install "flask>=3.1,<4"` - устанавливается Flask;
- `EXPOSE 8080` - указывается порт приложения;
- `CMD ["python", "main.py"]` - задается команда запуска приложения.

Для сборки образа использовалась команда:

```powershell
docker build -t malax123/hello-k8s:latest ./k8s-app
```

После сборки образ был опубликован в Docker Hub:

```powershell
docker push malax123/hello-k8s:latest
```

В Kubernetes-манифесте используется этот образ:

```yaml
image: malax123/hello-k8s:latest
```

Таким образом Kubernetes может скачать образ из Docker Hub и запустить контейнер в pod.

---

## 6. ConfigMap

Для передачи значения в приложение используется Kubernetes `ConfigMap`. Это отдельный объект Kubernetes, который позволяет хранить конфигурационные параметры отдельно от контейнерного образа.

Файл `k8s-app/configmap.yaml`:

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: hello-config
data:
  name: DevOps
```

В этом манифесте создается объект `ConfigMap` с именем `hello-config`. Внутри него хранится ключ `name` со значением `DevOps`.

Далее это значение используется в `Deployment` и передается в контейнер как переменная окружения `NAME`.

Преимущество такого подхода состоит в том, что конфигурация отделена от кода приложения. Например, можно изменить значение `name` в `ConfigMap`, не меняя исходный код Python-приложения и не пересобирая Docker-образ.

Применение `ConfigMap` выполнялось командой:

```powershell
kubectl apply -f k8s-app/configmap.yaml
```

Проверка созданного объекта:

```powershell
kubectl get configmap hello-config -o yaml
```

Пример результата:

```yaml
apiVersion: v1
data:
  name: DevOps
kind: ConfigMap
metadata:
  name: hello-config
  namespace: default
```
---

## 7. Deployment

Для запуска приложения в Kubernetes используется объект `Deployment`. Он отвечает за создание и поддержание нужного количества pod с приложением.

Фрагмент манифеста `Deployment`:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: hello-deploy
spec:
  replicas: 1
  selector:
    matchLabels:
      app: hello
  template:
    metadata:
      labels:
        app: hello
    spec:
      containers:
        - name: hello
          image: malax123/hello-k8s:latest
          imagePullPolicy: IfNotPresent
          ports:
            - containerPort: 8080
          env:
            - name: NAME
              valueFrom:
                configMapKeyRef:
                  name: hello-config
                  key: name
```

В данном `Deployment` задаются следующие параметры:

- имя deployment: `hello-deploy`;
- количество реплик: `1`;
- label приложения: `app: hello`;
- Docker-образ: `malax123/hello-k8s:latest`;
- порт контейнера: `8080`;
- переменная окружения `NAME`, значение которой берется из `ConfigMap`.

Связь с `ConfigMap` задается через блок:

```yaml
env:
  - name: NAME
    valueFrom:
      configMapKeyRef:
        name: hello-config
        key: name
```

Это означает, что Kubernetes берет значение ключа `name` из `ConfigMap` `hello-config` и записывает его в переменную окружения `NAME` внутри контейнера.

Применение `Deployment` выполнялось командой:

```powershell
kubectl apply -f k8s-app/deployment-fixed.yaml
```

Проверка:

```powershell
kubectl get deployment
```

Фактический результат:

```text
NAME           READY   UP-TO-DATE   AVAILABLE   AGE
hello-deploy   1/1     1            1           12m
```

Также была выполнена проверка pod:

```powershell
kubectl get pods
```

Фактический результат:

```text
NAME                           READY   STATUS    RESTARTS   AGE
hello-deploy-cf97d49f6-jqphg   1/1     Running   0          12m
```

Статус `Running` и значение `READY 1/1` означают, что контейнер успешно запущен и приложение работает внутри pod.

---

## 8. Service

Для доступа к pod внутри Kubernetes используется объект `Service`. Pod может пересоздаваться, и его IP-адрес может изменяться, поэтому обращаться напрямую к pod неудобно. `Service` дает стабильную точку доступа к приложению.

Фрагмент манифеста `Service`:

```yaml
apiVersion: v1
kind: Service
metadata:
  name: hello-svc
spec:
  selector:
    app: hello
  ports:
    - port: 80
      targetPort: 8080
  type: NodePort
```

В данном сервисе:

- имя сервиса: `hello-svc`;
- selector: `app: hello`;
- внешний порт сервиса внутри кластера: `80`;
- порт контейнера: `8080`;
- тип сервиса: `NodePort`.

Selector `app: hello` связывает `Service` с pod, который был создан через `Deployment`. В pod задан такой же label:

```yaml
labels:
  app: hello
```

Проверка сервиса:

```powershell
kubectl get svc
```

Фактический результат:

```text
NAME         TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)        AGE
hello-svc    NodePort    10.96.118.242   <none>        80:32139/TCP   12m
kubernetes   ClusterIP   10.96.0.1       <none>        443/TCP        13m
```

Из результата видно, что сервис `hello-svc` создан. Он принимает запросы на порт `80` и направляет их в контейнер на порт `8080`.

Для локальной проверки использовалась команда `port-forward`:

```powershell
kubectl port-forward svc/hello-svc 8080:80
```

После выполнения этой команды приложение доступно в браузере по адресу:

```text
http://localhost:8080
```
---

## 9. Ingress

Для маршрутизации HTTP-трафика к сервису был создан объект `Ingress`. Он позволяет обращаться к приложению по доменному имени и маршрутизировать запросы к нужному сервису.

Фрагмент манифеста `Ingress`:

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: hello-ingress
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /
spec:
  rules:
    - host: hello.local
      http:
        paths:
          - path: /
            pathType: Prefix
            backend:
              service:
                name: hello-svc
                port:
                  number: 80
```

В данном объекте:

- имя ingress: `hello-ingress`;
- host: `hello.local`;
- путь: `/`;
- backend service: `hello-svc`;
- порт сервиса: `80`.

Ingress связывает HTTP-запросы к адресу `hello.local` с сервисом `hello-svc`.

Проверка Ingress:

```powershell
kubectl get ingress
```

Фактический результат:

```text
NAME            CLASS    HOSTS         ADDRESS   PORTS   AGE
hello-ingress   <none>   hello.local             80      12m
```

Объект `Ingress` создан. В локальном окружении Docker Desktop поле `ADDRESS` может быть пустым, если ingress-controller не настроен или не назначил внешний адрес. Поэтому для быстрой проверки работоспособности приложения использовался `kubectl port-forward`.

Если ingress-controller настроен, для проверки через `hello.local` необходимо добавить запись в файл hosts:

```text
127.0.0.1 hello.local
```

Файл hosts в Windows находится по пути:

```text
C:\Windows\System32\drivers\etc\hosts
```

После этого приложение можно открыть в браузере:

```text
http://hello.local
```


---

## 10. Применение Kubernetes-манифестов

После подготовки приложения, Docker-образа и Kubernetes-манифестов ресурсы были применены в кластере.

Сначала применялся `ConfigMap`:

```powershell
kubectl apply -f k8s-app/configmap.yaml
```

Затем применялись `Deployment`, `Service` и `Ingress`:

```powershell
kubectl apply -f k8s-app/deployment-fixed.yaml
```

Фактический результат применения:

```text
configmap/hello-config unchanged
deployment.apps/hello-deploy unchanged
service/hello-svc unchanged
ingress.networking.k8s.io/hello-ingress unchanged
```

Слово `unchanged` означает, что ресурсы уже были созданы ранее и их конфигурация не изменилась. Если ресурсы создаются впервые, Kubernetes обычно выводит `created`.

После применения манифестов были проверены все основные объекты:

```powershell
kubectl get pods
kubectl get deployment
kubectl get svc
kubectl get ingress
kubectl get configmap
```

Эти команды позволяют убедиться, что все требуемые по заданию компоненты созданы в Kubernetes.

---

## 11. Проверка переменной окружения

Одним из требований задачи было использование параметра из переменной окружения или конфигурационного файла. В данной работе значение хранится в `ConfigMap`, а в контейнер попадает как переменная окружения `NAME`.

Для проверки была выполнена команда:

```powershell
kubectl exec deploy/hello-deploy -- printenv NAME
```

Фактический результат:

```text
DevOps
```

Этот вывод подтверждает, что:

- `ConfigMap` создан корректно;
- `Deployment` правильно ссылается на `ConfigMap`;
- переменная окружения `NAME` доступна внутри контейнера;
- приложение может использовать эту переменную при генерации HTML-страницы.

Также можно проверить логи приложения:

```powershell
kubectl logs deploy/hello-deploy --tail=20
```

Пример результата:

```text
* Serving Flask app 'main'
* Debug mode: off
* Running on all addresses (0.0.0.0)
* Running on http://127.0.0.1:8080
* Running on http://10.244.0.5:8080
```

Логи показывают, что Flask-приложение успешно запущено и слушает порт `8080`.


---

## 12. Проверка работоспособности приложения

Для проверки работы приложения использовался механизм `port-forward`, который пробрасывает порт сервиса Kubernetes на локальный компьютер.

Команда:

```powershell
kubectl port-forward svc/hello-svc 8080:80
```

После запуска этой команды сервис `hello-svc` становится доступен локально по адресу:

```text
http://localhost:8080
```

В браузере открывается HTML-страница с текстом:

```text
Hello, DevOps!
```

Также на странице отображается значение переменной окружения:

```text
Переменная окружения NAME = DevOps
```

Это подтверждает, что запрос проходит по цепочке:

```text
Browser -> localhost:8080 -> kubectl port-forward -> Service hello-svc -> Pod -> Flask application
```

Итоговая проверка показывает, что приложение:

- собрано в Docker-образ;
- запущено в Kubernetes;
- получает конфигурацию из `ConfigMap`;
- доступно через `Service`;
- имеет настроенный `Ingress`;
- возвращает HTML-страницу с параметром из конфигурации.

Место для вставки скриншота открытой страницы:

```text
[ВСТАВИТЬ СКРИНШОТ БРАУЗЕРА http://localhost:8080 С ТЕКСТОМ Hello, DevOps!]
```

---

## 13. Команды, использованные в работе

Ниже приведен список основных команд, которые использовались при выполнении задачи.

Проверка Kubernetes-контекста:

```powershell
kubectl config get-contexts
kubectl config current-context
kubectl cluster-info
```

Сборка Docker-образа:

```powershell
docker build -t malax123/hello-k8s:latest ./k8s-app
```

Публикация Docker-образа:

```powershell
docker push malax123/hello-k8s:latest
```

Применение Kubernetes-манифестов:

```powershell
kubectl apply -f k8s-app/configmap.yaml
kubectl apply -f k8s-app/deployment-fixed.yaml
```

Проверка ресурсов:

```powershell
kubectl get pods
kubectl get deployment
kubectl get svc
kubectl get ingress
kubectl get configmap
```

Проверка переменной окружения:

```powershell
kubectl exec deploy/hello-deploy -- printenv NAME
```

Проверка логов:

```powershell
kubectl logs deploy/hello-deploy --tail=20
```

Проброс порта для локальной проверки:

```powershell
kubectl port-forward svc/hello-svc 8080:80
```

Адрес для проверки в браузере:

```text
http://localhost:8080
```

---

## 14. Возможные проблемы и их решение

При переносе проекта на другой компьютер может возникнуть ситуация, когда репозиторий уже есть, но Kubernetes-кластер не настроен. В этом случае команды `kubectl get pods`, `kubectl get deployment` и другие могут завершаться ошибкой.

Причина состоит в том, что GitHub-репозиторий хранит исходный код и манифесты, но не хранит сам локальный Kubernetes-кластер. Кластер создается отдельно на конкретном компьютере.

Если используется Docker Desktop, необходимо:

- открыть Docker Desktop;
- перейти в настройки;
- включить Kubernetes;
- дождаться статуса `Running`;
- проверить контекст командой `kubectl config get-contexts`.

Если активный контекст не выбран, можно переключиться на Docker Desktop:

```powershell
kubectl config use-context docker-desktop
```

После этого можно заново применить манифесты:

```powershell
kubectl apply -f k8s-app/configmap.yaml
kubectl apply -f k8s-app/deployment-fixed.yaml
```

Еще одна возможная ситуация связана с `Ingress`. В Docker Desktop объект `Ingress` может быть создан, но поле `ADDRESS` может оставаться пустым. Для учебной проверки это не мешает подтвердить работоспособность приложения через `Service` и `port-forward`. Если требуется именно проверка через доменное имя `hello.local`, нужно дополнительно настроить ingress-controller и файл hosts.

---

## 15. Заключение

В результате выполнения работы было подготовлено и развернуто простое REST-приложение в Kubernetes. Приложение написано на Python с использованием Flask и возвращает HTML-страницу с приветствием.

Значение для приветствия передается через Kubernetes `ConfigMap`. Внутри контейнера оно доступно как переменная окружения `NAME`. При значении `DevOps` приложение возвращает страницу с текстом:

```text
Hello, DevOps!
```

Для приложения был подготовлен Dockerfile, выполнена сборка Docker-образа и настроено использование образа из Docker Hub:

```text
malax123/hello-k8s:latest
```

В Kubernetes были созданы все требуемые объекты:

- `ConfigMap` - для хранения значения `name`;
- `Deployment` - для запуска pod с приложением;
- `Service` - для доступа к приложению внутри кластера;
- `Ingress` - для настройки HTTP-маршрутизации.

Работоспособность была проверена с помощью команд `kubectl`, проверки переменной окружения внутри контейнера и открытия HTML-страницы в браузере через `port-forward`.

Таким образом, все требования задания были выполнены.

---
