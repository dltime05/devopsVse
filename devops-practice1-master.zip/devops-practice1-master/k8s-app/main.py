from flask import Flask
import os

app = Flask(__name__)

@app.route('/')
def hello():
    name = os.getenv('NAME', 'Guest')
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>K8S Hello App</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                margin: 50px;
                text-align: center;
                background-color: #eef4ff;
            }}
            h1 {{
                color: #2563eb;
            }}
        </style>
    </head>
    <body>
        <h1>Hello, {name}!</h1>
        <p>Переменная окружения NAME = <strong>{name}</strong></p>
        <hr>
        <small>Deployment + ConfigMap + Service + Ingress</small>
    </body>
    </html>
    '''

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
