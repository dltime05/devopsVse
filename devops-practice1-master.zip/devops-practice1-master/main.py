﻿from flask import Flask
import os

app = Flask(__name__)

@app.route('/')
def hello():
    name = os.getenv('NAME', 'Guest')
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>K8S Hello App</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                margin: 50px;
                text-align: center;
                background-color: #eef4ff;
            }}
            h1 {{
                color: #2563eb;
            }}
            .container {{
                background-color: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                display: inline-block;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Hello, {name}!</h1>
            <p>Переменная окружения NAME: <strong>{name}</strong></p>
            <p>Приложение запущено в Kubernetes через Deployment, Service и Ingress</p>
            <hr>
            <small>DevOps Practice</small>
        </div>
    </body>
    </html>
    '''

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
