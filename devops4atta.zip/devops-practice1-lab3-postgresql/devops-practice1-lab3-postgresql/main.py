﻿from flask import Flask, request, render_template_string
import os
import psycopg
from psycopg.rows import dict_row
import datetime

app = Flask(__name__)

DB_HOST = os.getenv('DB_HOST', 'postgres-svc')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_NAME = os.getenv('DB_NAME', 'messages_db')
DB_USER = os.getenv('DB_USER', 'postgres')
DB_PASSWORD = os.getenv('DB_PASSWORD', 'postgres123')

def get_db_connection():
    return psycopg.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        row_factory=dict_row
    )

HTML_TEMPLATE = '''
<!DOCTYPE html>
<html>
<head>
    <title>Message App</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
            text-align: center;
            background-color: #f0f0f0;
        }
        .container {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            max-width: 600px;
            margin: 0 auto;
        }
        h1 { color: #4CAF50; }
        .message-form { margin: 20px 0; }
        input[type="text"] {
            padding: 10px;
            width: 70%;
            margin-right: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover { background-color: #45a049; }
        .messages { margin-top: 30px; text-align: left; }
        .message {
            background-color: #f9f9f9;
            padding: 10px;
            margin: 10px 0;
            border-left: 4px solid #4CAF50;
            border-radius: 4px;
        }
        .time { font-size: 12px; color: #999; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Привет, {{ name }}!</h1>
        <p>Приложение с базой данных PostgreSQL</p>
        
        <div class="message-form">
            <form action="/add_message" method="post">
                <input type="text" name="message" placeholder="Введите ваше сообщение..." required>
                <button type="submit">Отправить</button>
            </form>
        </div>
        
        <div class="messages">
            <h3>Сообщения:</h3>
            {% if messages %}
                {% for msg in messages %}
                <div class="message">
                    <strong>Сообщение:</strong> {{ msg.message }}<br>
                    <span class="time">{{ msg.created_at }}</span>
                </div>
                {% endfor %}
            {% else %}
                <p>Нет сообщений. Будьте первым!</p>
            {% endif %}
        </div>
    </div>
</body>
</html>
'''

@app.route('/')
def index():
    name = os.getenv('NAME', 'Guest')
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT message, created_at FROM messages ORDER BY created_at DESC LIMIT 50')
    messages = cur.fetchall()
    cur.close()
    conn.close()
    return render_template_string(HTML_TEMPLATE, name=name, messages=messages)

@app.route('/add_message', methods=['POST'])
def add_message():
    message = request.form.get('message')
    if message and message.strip():
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('INSERT INTO messages (message, created_at) VALUES (%s, %s)', 
                   (message.strip(), datetime.datetime.now()))
        conn.commit()
        cur.close()
        conn.close()
    return '<script>window.location.href="/";</script>'

@app.route('/health')
def health():
    return {"status": "healthy"}

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
