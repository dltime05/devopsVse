# Отчет по лабораторной работе №4

## Helm, CRD & RBAC

**Выполнил:** Ветохин Д.В. — 9 группа

---

## 1. Введение

### 1.1. Цель работы

Целью работы является получение практических навыков развертывания приложений в Kubernetes с использованием Helm, работы с операторами (CloudNativePG, CertManager) и современными CRD-ресурсами (GatewayAPI). Работа выполняется на базе предыдущих лабораторных работ (ЛР2, ЛР3) в том же репозитории.

### 1.2. Задачи

1. Переработать развертывание из ЛР2 и ЛР3 с обычных манифестов на Helm-чарт.
2. Установить GatewayAPI через Helm (NGINX Gateway Fabric).
3. Заменить ручной StatefulSet для PostgreSQL на оператор CloudNativePG.
4. Добавить самоподписанные SSL-сертификаты через CertManager.
5. Проверить работоспособность всего стека.

---

## 2. Ход работы

### 2.1. Обзор приложения

В качестве приложения используется Flask-приложение на Python из предыдущих лабораторных работ. Оно отображает HTML-страницу с приветствием, формой отправки сообщений и списком сообщений из PostgreSQL.

В рамках ЛР4 приложение и его инфраструктура были переведены на Helm-чарт, а ручное управление StatefulSet и Ingress заменено на операторы и GatewayAPI.

### 2.2. Структура Helm-чарта

Все манифесты из ЛР2/ЛР3 были переработаны в Helm-чарт с шаблонизацией через values.yaml:

**values.yaml** содержит все настраиваемые параметры:

```yaml
app:
  name: Lev
  image: malax123/hello-k8s
  tag: latest
  replicas: 1

postgres:
  dbName: messages_db
  user: postgres
  password: postgres123
  storageSize: 5Gi
  instances: 1

gateway:
  className: envoy-gateway-class

certificate:
  dnsNames:
    - hello.local
  duration: 8760h
```
установили имя, пароль и тд

### 2.3. Установка операторов через Helm

В отличие от ЛР2/ЛР3, где операторы устанавливались вручную, в ЛР4 все операторы устанавливаются через Helm.

#### CloudNativePG

```bash
helm repo add cnpg https://cloudnative-pg.io/charts/
helm install cnpg cnpg/cloudnative-pg --namespace cnpg-system --create-namespace
```

CloudNativePG заменяет ручной StatefulSet. Оператор автоматически создает и управляет PostgreSQL-кластером


#### CertManager

```bash
helm install cert-manager jetstack/cert-manager \
  --namespace cert-manager --create-namespace \
  --set crds.enabled=true
```

CertManager автоматизирует создание и обновление SSL-сертификатов.

#### GatewayAPI (NGINX Gateway Fabric)

```bash
helm install ngf oci://ghcr.io/nginx/charts/nginx-gateway-fabric \
  --create-namespace -n nginx-gateway
```

### 2.4. Развертывание PostgreSQL через CloudNativePG

Вместо ручного StatefulSet из ЛР2/ЛР3 создается CR `Cluster` по заданию:

```yaml
apiVersion: postgresql.cnpg.io/v1
kind: Cluster
metadata:
  name: hello-app-pg
spec:
  instances: 1
  storage:
    size: 5Gi
  bootstrap:
    initdb:
      database: messages_db
      owner: postgres
      secret:
        name: postgres-secret
```

CloudNativePG автоматически:

Создает под с PostgreSQL.
Создает PersistentVolumeClaim для хранения данных.
Настраивает сервисы для доступа к БД (`hello-app-pg-rw`, `hello-app-pg-ro`, `hello-app-pg-r`).
Создает сертификаты для TLS-соединений.

Сервисы CloudNativePG:

- `hello-app-pg-rw` — read-write endpoint (используется приложением).
- `hello-app-pg-ro` — read-only endpoint.
- `hello-app-pg-r` — реплики.

Проверка кластера:

```bash
kubectl get cluster
```

Результат: кластер готов

```
NAME           AGE   INSTANCES   READY   STATUS                     PRIMARY
hello-app-pg   82s   1           1       Cluster in healthy state   hello-app-pg-1
```

### 2.5. сертификаты CertManager

В ЛР4 добавлены самоподписанные SSL-сертификаты для обеспечения HTTPS-доступа к приложению.

#### ClusterIssuer

Создается самоучрежденный центр сертификации (CA):

```yaml
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: selfsigned-issuer
spec:
  selfSigned: {}
```

#### Certificate

На основе ClusterIssuer создается сертификат для домена `hello.local`:

```yaml
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: hello-cert
spec:
  dnsNames:
    - hello.local
  issuerRef:
    name: selfsigned-issuer
    kind: ClusterIssuer
  secretName: hello-cert
  duration: 8760h
```

CertManager автоматически создает Secret `hello-cert` с сертификатом и ключом. Этот Secret используется в Gateway для HTTPS.

Проверка сертификата:

```bash
kubectl get certificate
```

Результат:

```
NAME         READY   SECRET       AGE
hello-cert   True    hello-cert   20s
```

### 2.6. GatewayAPI с HTTPS

Gateway настроен на прием HTTPS-трафика с использованием сертификата от CertManager:

```yaml
apiVersion: gateway.networking.k8s.io/v1
kind: Gateway
metadata:
  name: hello-gateway
spec:
  gatewayClassName: envoy-gateway-class
  listeners:
    - name: https
      protocol: HTTPS
      port: 443
      tls:
        mode: Terminate
        certificateRefs:
          - name: hello-cert
```

HTTPRoute направляет трафик на сервис приложения:

```yaml
apiVersion: gateway.networking.k8s.io/v1
kind: HTTPRoute
metadata:
  name: hello-httproute
spec:
  parentRefs:
    - name: hello-gateway
  rules:
    - matches:
        - path:
            type: PathPrefix
            value: /
      backendRefs:
        - name: hello-svc
          port: 80
```

### 2.7. Развертывание приложения через Helm

После установки операторов приложение разворачивается одной командой:

```bash
helm install hello-app ./app-chart
```

Helm создает все необходимые ресурсы:

ConfigMap — передает имя пользователя в переменную окружения `NAME`.
Secret — хранит пароль PostgreSQL.
Deployment — запускает под приложения с образом `malax123/hello-k8s:latest`.
Service — открывает доступ к приложению через NodePort.
CloudNativePG Cluster — создает PostgreSQL.
ClusterIssuer + Certificate — настраивает SSL-сертификаты.
Gateway + HTTPRoute — настраивает маршрутизацию через GatewayAPI.

Проверка подов:

```bash
kubectl get pods
```

Результат: все подики у нас поднялись

```
NAME                              READY   STATUS    RESTARTS   AGE
hello-app-6c99c7bcb8-ncbd9        1/1     Running   0          2m
hello-app-pg-1                    1/1     Running   0          2m
```

### 2.8. Проверка работоспособности

После развертывания всех компонентов была выполнена проверка.

Проверка подов и сервисов:

```bash
kubectl get pods,svc,gateway,httproute,cluster,certificate
```



Открывал страницу ->

Через Minikube tunnel:

```bash
minikube service hello-svc
```
Открывается страница как в лаб3



## 3. Выводы

В ходе выполнения практического задания №4 мы перевели все настройки из прошлых работ в Helm-чарт с шаблонами. Это значит, что теперь всё приложение разворачивается одной командой helm install, а все переменные и конфигурации лежат в одном файле values.yaml — удобно и понятно. Мы установили и настроили операторы: CloudNativePG, который сам управляет PostgreSQL (создаёт базы, делает бэкапы, следит за сохранностью данных), и CertManager, который автоматически выдаёт и обновляет SSL-сертификаты для HTTPS. 
Настроили Gateway с HTTPS через сертификат от CertManager — это более современная и гибкая штука, чем обычный Ingress, с разделением ролей и поддержкой разных протоколов. В итоге Helm-чарт можно одной командой развернуть в любом кластере Kubernetes, операторы сами делают всю рутинную работу, а приложение работает по HTTPS и сохраняет данные даже после перезапусков.