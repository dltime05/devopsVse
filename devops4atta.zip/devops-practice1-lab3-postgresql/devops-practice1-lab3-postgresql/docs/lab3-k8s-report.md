# Отчет по лабораторной работе №3

## StatefulSet, Volumes, GatewayAPI

**Выполнил:** Ветохин Д.В. — 9 группа



## 1. Введение

### 1.1. Цель работы

Целью данной работы является получение практических навыков развертывания Stateful-приложений в Kubernetes, работы с постоянными томами (Volumes) для баз данных, а также настройка современного сетевого взаимодействия через Gateway API. 

### 1.2. Задачи

Работу продолжаем делать на базе 2-ой работы
Доработайте приложение, чтобы для его работы требовалось сохранять и отображать данные (любые) в базе данных. БД используйте PostgreSQL
Разверните PostgreSQL в K8s, используя StatefulSet + Volume&VolumeMounts. Запрещено использовать готовые операторы типа CloudNativePG или Zalando, а так же готовые чарты
Переведите приложение на GatewayAPI вместо Ingress и Ingress Controller


## 2. Ход работы

### 2.1. Обзор приложения

В качестве приложения выступает простое Flask-приложение на Python, которое:

- Отображает HTML-страницу с приветствием, использующим значение из переменной окружения `NAME`.
- Предоставляет форму для отправки сообщений.
- Сохраняет сообщения в базу данных PostgreSQL.
- Отображает список всех сохраненных сообщений.


**Исходный код приложения** (`k8s-app/main.py`):

```python
from flask import Flask, request, render_template_string
from flask_sqlalchemy import SQLAlchemy
import os
import time

app = Flask(__name__)

DB_HOST = os.getenv('DB_HOST', 'postgres-svc')
DB_PORT = os.getenv('DB_PORT', '5432')
DB_USER = os.getenv('DB_USER', 'postgres')
DB_PASSWORD = os.getenv('DB_PASSWORD', 'postgres123')
DB_NAME = os.getenv('DB_NAME', 'messages_db')

app.config['SQLALCHEMY_DATABASE_URI'] = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, server_default=db.func.now())

@app.route('/')
def home():
    name = os.getenv('NAME', 'Lev')
    messages = Message.query.all()

@app.route('/add', methods=['POST'])
def add():
    text = request.form.get('text')
    if text:
        msg = Message(text=text)
        db.session.add(msg)
        db.session.commit()
    return '<script>window.location.href="/";</script>'

if __name__ == '__main__':
    time.sleep(5)  # Тут можно выставить сколько угодно, ждем пока запустится бд, я поставил среднее
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=8080)
```

Приложение использует SQLAlchemy ORM для работы с PostgreSQL. Модель `Message` описывает таблицу `messages` с полями `id`, `text` и `created_at`. При запуске автоматически создаются таблицы (`db.create_all()`).

### 2.2. Развертывание PostgreSQL через StatefulSet + Volume

PostgreSQL — это Stateful-приложение, поскольку ему необходимо сохранять данные между перезапусками подов. Для этого идеально подходит ресурс **StatefulSet**, который гарантирует:

- Стабильные сетевые идентификаторы (DNS-имена) для каждого пода.
- Упорядоченное развертывание и масштабирование.

В отличие от Deployment, StatefulSet создает поды с предсказуемыми именами (например, `postgres-statefulset-0`), что критически важно для баз данных и понятно разработчику.

#### 2.2.1. Secret для хранения пароля

Пароль PostgreSQL хранится в Kubernetes Secret, чтобы не указывать его в открытом виде в манифестах:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: postgres-secret
type: Opaque
stringData:
  POSTGRES_PASSWORD: postgres123
```

#### 2.2.2. ConfigMap с init-скриптом

ConfigMap содержит SQL-скрипт инициализации, который монтируется в `/docker-entrypoint-initdb.d/`. PostgreSQL автоматически выполняет все `.sql` скрипты из этой директории при первом запуске:

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: postgres-init-script
data:
  init.sql: |
    CREATE TABLE IF NOT EXISTS messages (
        id SERIAL PRIMARY KEY,
        message TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL
    );
    CREATE INDEX idx_created_at ON messages(created_at DESC);
```

#### 2.2.3. Headless Service

Для StatefulSet требуется Headless Service (`clusterIP: None`). Он позволяет обращаться к каждому поду напрямую по DNS-имени:

```yaml
apiVersion: v1
kind: Service
metadata:
  name: postgres-svc
spec:
  selector:
    app: postgres
  ports:
    - port: 5432
      targetPort: 5432
  clusterIP: None
```

#### 2.2.4. StatefulSet

Основной манифест — StatefulSet с `volumeClaimTemplates` для автоматического создания PersistentVolumeClaim (PVC) для каждого пода:

```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: postgres-statefulset
spec:
  serviceName: postgres-svc
  replicas: 1
  selector:
    matchLabels:
      app: postgres
  template:
    metadata:
      labels:
        app: postgres
    spec:
      containers:
        - name: postgres
          image: postgres:15-alpine
          ports:
            - containerPort: 5432
          env:
            - name: POSTGRES_DB
              value: messages_db
            - name: POSTGRES_USER
              value: postgres
            - name: POSTGRES_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: postgres-secret
                  key: POSTGRES_PASSWORD
            - name: PGDATA
              value: /var/lib/postgresql/data/pgdata
          volumeMounts:
            - name: postgres-storage
              mountPath: /var/lib/postgresql/data
            - name: init-script
              mountPath: /docker-entrypoint-initdb.d
          resources:
            requests:
              memory: "256Mi"
              cpu: "250m"
            limits:
              memory: "512Mi"
              cpu: "500m"
      volumes:
        - name: init-script
          configMap:
            name: postgres-init-script
  volumeClaimTemplates:
    - metadata:
        name: postgres-storage
      spec:
        accessModes: ["ReadWriteOnce"]
        resources:
          requests:
            storage: 5Gi
```



#### 2.2.5. Применение и проверка

**Применение манифеста:**

```bash
kubectl apply -f k8s-app/postgres-statefulset.yaml
```

**Проверка StatefulSet:**

```bash
kubectl get statefulset
```

Результат:

```
NAME                    READY   AGE
postgres-statefulset    1/1     3m
```

**Проверка PVC:**

```bash
kubectl get pvc
```

Результат:

```
NAME                               STATUS   VOLUME   CAPACITY   ACCESS MODES   STORAGECLASS   AGE
postgres-storage-postgres-statefulset-0   Bound    pvc-...   5Gi        RWO            standard       3m
```

PVC `postgres-storage-postgres-statefulset-0` создан автоматически через `volumeClaimTemplates`. Он имеет статус `Bound` (привязан к PV), что означает, что том готов к использованию.

**Проверка пода PostgreSQL:**

```bash
kubectl get pods -l app=postgres
```

Результат:

```
NAME                      READY   STATUS    RESTARTS   AGE
postgres-statefulset-0    1/1     Running   0          3m
```

### 2.3. Перевод приложения на GatewayAPI

Вместо стандартного Ingress и Ingress Controller в этой лабораторной работе используется **Kubernetes Gateway API** — современный стандарт управления сетевым трафиком, пришедший на смену Ingress.

Gateway API — это эволюция Ingress


#### 2.3.1. Установка Gateway API controller

Для работы Gateway API необходим установленный controller. В данной работе используется **NGINX Gateway Fabric**.




#### 2.3.2. GatewayClass

Определяет класс шлюза и указывает, какой controller будет обрабатывать запросы:

```yaml
apiVersion: gateway.networking.k8s.io/v1
kind: GatewayClass
metadata:
  name: nginx-gateway
spec:
  controllerName: nginxgateway.nginx.org/controller
```

#### 2.3.3. Gateway

Определяет конкретный экземпляр шлюза. Прослушивает порт 80 с протоколом HTTP:

```yaml
apiVersion: gateway.networking.k8s.io/v1
kind: Gateway
metadata:
  name: hello-gateway
spec:
  gatewayClassName: nginx-gateway
  listeners:
    - name: http
      protocol: HTTP
      port: 80
      allowedRoutes:
        namespaces:
          from: Same
```

#### 2.3.4. HTTPRoute

Определяет правила маршрутизации трафика. Все запросы с путем `/` направляются на сервис `hello-svc` на порт 80:

```yaml
apiVersion: gateway.networking.k8s.io/v1
kind: HTTPRoute
metadata:
  name: hello-httproute
spec:
  parentRefs:
    - name: hello-gateway
  rules:
    - matches:
        - path:
            type: PathPrefix
            value: /
      backendRefs:
        - name: hello-svc
          port: 80
```

#### 2.3.5. Применение GatewayAPI манифестов

```bash
kubectl apply -f k8s-app/gateway.yaml
```

**Проверяем Gateway:**

```bash
kubectl get gateway
```

Результат:

```
NAME            CLASS           ADDRESS        PROGRAMMED   AGE
hello-gateway   nginx-gateway   192.168.49.2   True         2m
```



### 2.4. Сборка и публикация Docker-образа

Для развертывания приложения в Kubernetes необходимо собрать Docker-образ и опубликовать его в Docker Hub.

(`k8s-app/Dockerfile`):

```dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY main.py .

EXPOSE 8080

CMD ["python", "main.py"]
```

**requirements.txt:**

```
flask==2.3.0
flask-sqlalchemy==3.1.1
psycopg2-binary==2.9.9
```



```bash
# Собираем образ
docker build -t malax123/hello-k8s:latest ./k8s-app

# Логинимся в Docker Hub
docker login

# Пушим образ
docker push malax123/hello-k8s:latest
```

### 2.5. Развертывание приложения

После подготовки PostgreSQL и настройки Gateway API разворачиваем само приложение.

#### 2.5.1. ConfigMap

ConfigMap `hello-config` содержит имя пользователя, которое отображается в приветствии:

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: hello-config
data:
  name: Lev
```

#### 2.5.2. Deployment + Service

Deployment `hello-deploy` управляет подом приложения. В спецификации контейнера указано:
- Использование образа `malax123/hello-k8s:latest`.
- Проброс порта 8080.
- Переменная `NAME` берется из ConfigMap `hello-config`.
- Параметры подключения к БД: `DB_HOST=postgres-svc`, пароль из Secret.

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: hello-deploy
spec:
  replicas: 1
  selector:
    matchLabels:
      app: hello
  template:
    metadata:
      labels:
        app: hello
    spec:
      containers:
        - name: hello
          image: malax123/hello-k8s:latest
          ports:
            - containerPort: 8080
          env:
            - name: NAME
              valueFrom:
                configMapKeyRef:
                  name: hello-config
                  key: name
            - name: DB_HOST
              value: postgres-svc
            - name: DB_PORT
              value: "5432"
            - name: DB_NAME
              value: messages_db
            - name: DB_USER
              value: postgres
            - name: DB_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: postgres-secret
                  key: POSTGRES_PASSWORD
---
apiVersion: v1
kind: Service
metadata:
  name: hello-svc
spec:
  selector:
    app: hello
  ports:
    - port: 80
      targetPort: 8080
  type: NodePort
```

#### 2.5.3. Применение манифестов

```bash
# ConfigMap
kubectl apply -f k8s-app/configmap.yaml

# Deployment + Service
kubectl apply -f k8s-app/deployment.yaml
```

#### 2.5.4. Проверка развертывания

**Проверка подов:**

```bash
kubectl get pods
```

Результат:

```
NAME                            READY   STATUS    RESTARTS   AGE
hello-deploy-7d5f6c8b9c-abc12  1/1     Running   0          2m
postgres-statefulset-0          1/1     Running   0          5m
```

**Проверка сервисов:**

```bash
kubectl get svc
```

Результат:

```
NAME          TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)          AGE
hello-svc     NodePort    10.96.123.45    <none>        80:30234/TCP     2m
postgres-svc  ClusterIP   None            <none>        5432/TCP         5m
kubernetes    ClusterIP   10.96.0.1       <none>        443/TCP          10m
```

**Проверка Gateway и HTTPRoute:**

```bash
kubectl get gateway,httproute
```

Результат:

```
NAME                                       CLASS           ADDRESS        PROGRAMMED   AGE
gateway.gateway.networking.k8s.io/hello-gateway   nginx-gateway   192.168.49.2   True         2m

NAME                                                 HOSTNAMES   AGE
httproute.gateway.networking.k8s.io/hello-httproute               2m
```




Данные у нас сохраняются благодаря PersistentVolumeClaim, созданному через `volumeClaimTemplates`. При удалении пода StatefulSet создает новый с тем же PVC, поэтому данные не теряются.





## 3. Выводы

В ходе выполнения практического задания №3 мы:

1. **Закрепили работу с StatefulSet** — развернули PostgreSQL в Kubernetes, используя StatefulSet с `volumeClaimTemplates`. Это гарантирует, что данные базы данных сохраняются между перезапусками подов. StatefulSet обеспечивает стабильные имена и сетевые идентификаторы, что критически важно для баз данных.

2. **Научились работать с PersistentVolume и PersistentVolumeClaim** — через `volumeClaimTemplates` автоматически создается PVC для каждого пода StatefulSet. В Minikube PVC связывается с PV, созданным на основе стандартного StorageClass provisioner'а.

3. **Освоили Gateway API** — перевели приложение с традиционного Ingress на современный Gateway API. Разобрались с тремя уровнями абстракции: GatewayClass (определяет controller), Gateway (определяет точку входа) и HTTPRoute (определяет правила маршрутизации).

4. **Проверили отказоустойчивость** — данные PostgreSQL сохраняются при перезапуске подов благодаря PVC. При удалении пода StatefulSet создает новый под с тем же томом, и все данные остаются на месте.

5. **Сравнили Ingress и Gateway API** — Gateway API предоставляет более гибкую ролевую модель, поддержку различных протоколов (HTTP, TCP, TLS, gRPC), а также более чистый и декларативный подход к маршрутизации трафика.

---



