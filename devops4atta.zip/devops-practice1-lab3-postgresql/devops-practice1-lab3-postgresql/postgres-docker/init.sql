﻿CREATE TABLE IF NOT EXISTS messages (
    id SERIAL PRIMARY KEY,
    message TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL
);
CREATE INDEX idx_created_at ON messages(created_at DESC);

-- Добавляем тестовое сообщение
INSERT INTO messages (message, created_at) VALUES 
('Добро пожаловать в приложение с PostgreSQL!', NOW());
