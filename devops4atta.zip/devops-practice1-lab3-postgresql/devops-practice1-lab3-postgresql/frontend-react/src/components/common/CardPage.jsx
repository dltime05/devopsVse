import { MDBCard, MDBCardBody } from 'mdb-react-ui-kit'

export function CardPage({ title, children }) {
  return (
    <MDBCard className='panel-card auth-card'>
      <MDBCardBody>
        <h3 className='page-card-title'>{title}</h3>
        {children}
      </MDBCardBody>
    </MDBCard>
  )
}
